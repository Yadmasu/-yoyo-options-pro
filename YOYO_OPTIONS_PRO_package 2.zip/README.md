# YOYO OPTIONS PRO — deployment

1. Back up your existing repository before replacing files.
2. Copy `index.html`, `stock_signal.py`, and `.github/workflows/stock-signal.yml` into the GitHub Pages repository. Remove or disable any old workflow that also writes `stock_signal.json` or `stock_signals.json` to prevent conflicts.
3. GitHub Settings → Secrets and variables → Actions: set `ALPHA_VANTAGE_API_KEY`. Optional: set `TRADIER_TOKEN` (requires a Tradier market data entitlement). Use `TRADIER_BASE_URL` only if you know the correct Tradier environment. **Never put tokens in index.html.**
4. GitHub Settings → Actions → General → Workflow permissions: enable Read and write permissions if needed. Run YOYO Stock Signal manually once. GitHub Pages should publish the repository root.
5. Verify `stock_signals.json` exists and includes each expected symbol. **It takes at least 5 successful runs at 5 symbols/run to cover all 25 symbols**. The free Alpha Vantage API may allow fewer calls per day; set `SYMBOLS_PER_RUN=1` if necessary. A successful run does not mean all 25 were refreshed.
6. Verify the site on iPhone and desktop before inviting members.

## Important limitations

- The feed is experimental and cannot provide verified CALL/PUT trading advice.
- Options quotes require a real Tradier token with access to the options endpoints. Without it, the interface explicitly says unavailable.
- Tradier API market data can be delayed, unavailable, or require a paid subscription. This project does not verify quote freshness or contract tradability.
- The expiration calendar shows Fridays only; holidays and actual listed contracts are not guaranteed.
- This static GitHub Pages site **does not implement private member accounts, payments, or a 100-user access cap**. That requires an authenticated backend and security testing.
- The workflow runs weekdays once in UTC; data may not be final at the moment of execution. The page withholds old signals.
- Provider limits may make 25 symbols impractical on a free API plan.
